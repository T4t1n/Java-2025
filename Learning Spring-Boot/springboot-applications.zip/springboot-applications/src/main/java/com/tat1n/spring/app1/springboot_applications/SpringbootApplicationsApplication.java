package com.tat1n.spring.app1.springboot_applications;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootApplicationsApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootApplicationsApplication.class, args);
	}

}
