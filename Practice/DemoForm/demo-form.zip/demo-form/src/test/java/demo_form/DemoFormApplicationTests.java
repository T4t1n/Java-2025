package demo_form;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoFormApplicationTests {

	@Test
	void contextLoads() {
	}

}
